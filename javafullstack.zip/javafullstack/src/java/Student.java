package java;

public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				
				        String city="delhi";
				        if(city=="meerut") {
				        	System.out.println("city is meerut");
				        }else if(city=="karnataka"){
				        	System.out.println("city is karnataka");
				        }else if(city=="latur"){
				        	System.out.println("city is latur");  
				        	
				        }
				        else {
				        	System.out.println("city name");
				        		
				        	}
				        }
		}


				// TODO Auto-generated method stub

			}

		}

	}

}
