package java;

import java.util.Scanner;

public class Studen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
      System.out.println(".........");
      
	}

}
