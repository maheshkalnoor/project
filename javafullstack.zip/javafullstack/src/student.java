   
public class student {
	public static void main(String[]args) {
		        int x=10;
				int y=12;
				if(x+y<10) {
					System.out.println("x+y less than 10");
				}else {
					System.out.println("x+y greater than 20");
				}
				
	}

}
