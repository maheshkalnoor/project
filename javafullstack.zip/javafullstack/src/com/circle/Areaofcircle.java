package com.circle;

import java.util.Scanner;

public class Areaofcircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Functionsofcircle func=new Functionsofcircle();
        Scanner sc=new Scanner(system.in);
        System.out.println("Enter the radius");
        int radius=sc.nextInt();
        Double area=func.Area(radius);
        Double circum=func.Circumference(radius);
        System.out.println("Area is :"+arae);
        System.out.println("circumfernce is :"+circum);
	}

}
