/*package javafullstack;

public class basic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  System.out.println("shree Revansiddeshwar prasana");
	}

}*/
public class Student {
	public static void main(string[]args) {
		        int x=10;
				int y=12;
				if(x+y<10) {
					System.out.println("x+y less than 10");
				}else {
					System.out.println("x+y greater than 20");
				}
				
	}

}

