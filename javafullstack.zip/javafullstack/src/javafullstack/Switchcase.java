package javafullstack;

import java.util.Scanner;

public class Switchcase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc=new Scanner (System.in);
        String foodprice=sc.nextLine();
        switch(foodprice){
        case "panner":
            System.out.println( "food price 90");
            break;
        case "kaju khurma":
        	System.out.println("food price100");
        	break;
        case "jeera rice":
        	System.out.println("food price 150");
        	break;
        case "veg biryani":
        	System.out.println("food price 20");
        	break;
        case "rice":
              System.out.println("120");
              break
      ;   default:
    	      System.out.println("that choose food is there no");
      
	}

	}
}