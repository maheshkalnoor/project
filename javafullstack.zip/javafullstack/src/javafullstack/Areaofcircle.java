package javafullstack;

import java.util.Scanner;

public class Areaofcircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Functionsofcircle Area=new Functionsofcircle(;
     Scanner sc=new Scanner(System.in);
     System.out.println("enter the radius");
     int radius=sc.nextInt();
     Double area=func.Area(radius);
     Double circum=func.circumference(radius);
       System.out.println("area is :"+area);
     System.out.println("sircumfernce is "+circum);
	}
}	

	


